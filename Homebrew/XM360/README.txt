Team-xedev presents
XM360 - By node21

If you love XM360, please donate via paypal: xm360donate@gmail.com
------------------------------------------------------------------

Typical usage:
Launch XM360.xex
Choose Scan All - This will show you all XBLA titles installed (choose Unlock to unlock them if needed)
Choose Collection Manager 

Once in the Collection Manager you will see a list of all known XBLA titles.  They will be marked as:
"Have" - it is installed
"Missing" - it is missing
"Ignored" - it is ignored

A title reaches the "Ignored" state by selecting it in the list, and pressing the "X" button.

The "Y" button will filter the list in the following order:
ALL (all existing titles)
Just Missing
Just Have
Just Ignored

After you are done, you should find a file in the root of your usb stick (or elsewhere, see xm360.cfg) called xbla_report.txt.  That will list all of your missing titles.  

As more XBLA titles come out, you can place a file in the root of your usb stick (or elsewhere, see xm360.cfg) called xbla_titles.csv. 


As of version 1.8c, the old scraping perl script is compatible again, but it's not smart, and is much slower.  You should be using XM360_server instead.

Usage: XM360server.exe /? - list options
       XM360server.exe /D - update or create dlc_titles.csv in the current directory and exit
       XM360server.exe /X - update or create xbla_titles.csv in the current directory and exit
       XM360server.exe /L {locale} - optionally specify the locale (defaults to en-US).  Only useful before /D or /X
       XM360server.exe /U {URL} - optionally specify the URL (defaults to catalog.xboxlive.com).  Only useful before /D or /X
       XM360server.exe - with no parameters runs the server (doesn't exit)

Sample:
XM360server.exe /X  (update XBLA_titles.csv and exit)
XM360server.exe /U catalog.xboxlive.com /L en-US /D (update DLC_titles.csv and exit, URL and Locale specifically overridden)


version history:

Version 0.2:
*Added version display to screen
*Search 3 different paths for installed XBLA titles
*    hdd:\\Content\\0000000000000000
*    usb:\\Content\\0000000000000000
*    usb:\\360dashit\\Content\\0000000000000000

=-=-=-=-=

Version 0.3 -- Jan, 17th, 2010:
* Changed source of data so now we have released date, rating (0 thru 20), and number of ratings
* The "B" button will change what you are sorting on (title, release date, rating, number of ratings)
* MAKE SURE that you delete your old xbla_titles.csv on the root of your USB drive if you have one there 
* New script to recreate the database is included, but it take *MUCH* *MUCH* longer to run if you need to run it (you should only need it once a week or so when new titles are released, if you care to be that up-to-date)

=-=-=-=-=

Version 0.4 -- Jan 20th, 2010:
* Added ability to launch titles directly from the Scan list, or the Collection Manager List  (for  titles that you actually have) [use the A button]
* added support for multiple usb devices being connected
* More information is added the the resulting xbla_report.txt so you can choose to ignore missing titles that are rated very low.
* Some titleIds are intentionally duplicated since they exist in the wild, but aren't on the MS web site.  You should simply "Ignore" (with the X button) the versions that you don't have (assuming you care about such things)

=-=-=-=-=

Version 0.5 --
* Added support for all screen resolutions
* Added button to return to dash.  This might take a bit of time since this is when it writes the report file to the USB stick.  This also means that if you exit via the center X on the controller, the report won't get written (unless you had clicked on Scan, which exits the Collection Manager and also causes it to write the report)
* Added titles that you have, and that are excluded to new sections of the report.  The Have titles include their full path.  This can help you figure out why NXE can't see them, but XM360 can.

=-=-=-=-=

Version 0.6b -- Jan 30th, 2010
* Massive rewrite to support DLC (so, expect some bugs)
* Supoort for viewing your installed DLC, and unlocking it
* layout isn't great, but it works well enough for now
* the button to unlock DLC *only* affects the DLC currently listed.  So, if you want to unlock it all, make sure you have selected the <All> category
* the xbla_report.txt is written any time you exit the Collection Manager, so expect it to be a little slow.  I'll probably add a button for the next release.
* Include "hdd:\\360dashit\\Content\\0000000000000000" as a source of XBLA files
* When sorting by ratings, higher number of raters counts for more.  Also, highest ratings are at the top now, not the bottom
* 0.6b fixes launching correct titles from within Collection Manager

=-=-=-=-=

Version 0.7 -- Feb 10th, 2010
* Further massive rewrites :-)
* Automatically scan on launch, showing progress
* That ugly fixed-width font is gone, except where needed (the XBLA Collection Manager list)
* Support for DLC "Collection Management" - it's integrated into the "Show DLC" scene.  Be sure to use LB and RB to change views.  Note there are *lot's* of missed matches, mostly because what is *inside* the DLC files doesn't match what is on the marketplace web site.  Because of this, there is also the ablity to show content which you have, but wasn't scraped from the web site.
* There is a button to write the DLC report.  It takes a while, and only includes information on DLC for which you have at least one title.
* Like scraping for XBLA, there is an included scrapeMS_DLC.pl perl script.  It takes a very long time to complete.  You shouldn't need it often.  XM360 will search for a file called DLC_titles.csv before using the one included in the package.
* There's a button to generate the XBLA_report.txt instead of doing it all the time.
* Entirely new support for Title Updates.  Including the ability to Delete them.
* Support for deleteing XBLA titles.
* Support for deleteing DLC titles.

=-=-=-=-=-=

Version 0.8 -- Feb 11th, 2010
* Added support for a "backup" Cache folder.  (hdd:\Cache2)  Ability to see where your Title Updates are, and to restore from Cache2.
* Sorted initial screen by title.
* Added some special handling for Super Contra.

=-=-=-=-=-=

Version 0.8b -- Feb 13th, 2010
* fixed bug where Japanese DLC would prevent DLC scene from working (causing a 360 hang)

=-=-=-=-=-=

Version 0.8c -- Feb 13th, 2010
* fixed bug where launching XBLA from the first screen would launch wrong title
* fixed scraper for XBLA to include UTF-8 encoded text.  This makes them look nicer in xm360, and gets rid of the trailing "a" that was on some titles.

=-=-=-=-=-=

Version 0.9 -- Feb 15th, 2010
* introduced a "config" file where directory preferences can be set.  By default, xm360 looks for hdd:\config\xm360\xm360.cfg.  If it can't find that, it uses the one included with xm360.  See the contents of that file for more information.
* Some visual changes that include the use of icons to represent missing and ignored titles.  This frees up some screen UI as well.
* Some button changes so that they are consistent between the DLC and the XBLA Collection mgmt screen.
* Delete and Toggle Ignore are both on the X button now.  It will make sense as you start to use it.
* DLC collection management is quite a bit more useful now.  It no longer seperates "existing" content and content that was found but not "matched".  Furthermore, with the addition of the ability to "ignore" DLC content, you can now begin to clean up the discrepancies.  If you use LB to show titles for which you have some DLC, and then move to the rightmost list, you can see content that you have that didn't match.  If you then tell it to "ignore" the version that you don't have (because you really do), the list gets cleaner and cleaner.
* Added a message when the reports are finished being written

=-=-=-=-=-=

Version 1.0 -- Feb 19th, 2010
* For DLC titles that you have, the text at the bottom of the screen will indicate "Not Scraped" for titles that you have but couldn't be matched with the marketplace website.  This is usually an indication that you should find the one from the marketplace and mark it as "ignore."
* The default view for the DLC scene (when it first shows up) is now titles for which you have some DLC (makes more sense to start there)
* The <All> setting in the DLC scene now works correctly.  It used to always show everything instead of paying attention to the filter.
* You now have the ability to "Ignore" entire titles.  So, if you never plan to have any "Lips" DLC, then mark "Lips" as ignored.  This allows you to clean up the view of all existing DLC, if you care to do so.  This concept carries over the the report that you can output as well.  An ignored title will have none of it's DLC reported, but the title itself will be reported at the end where it reports on titles that are ignored.  Makes sense?  
* Title Update scene allows you to backup all TU files to hdd:\Cache2 (the reverse of the already implemented Restore)
* Title Update scene allows you to backup/restore single TU files 
* Added temperature display to all scenes

=-=-=-=-=-=

Version 1.1 -- Feb 26th, 2010
* Added ftp server, and because of that, a new button to "Rescan".  Also, your 360's IP address is displayed on screen.
* Fixed long standing issue where some titles weren't unlocking, and some weren't being scanned properly.  It had only minor impact though, so you might not have been aware of it.
* Added feature to "restore" DLC filenames.  As it turns out, some people are somehow getting DLC which has been renamed.  This feature will correct the filenames on the HDD.  However, it also seems that some of this DLC is being modified in order to "tag" it, or to "claim" it.  For example: some complete asshole calling himself "DragonSlayer" is releasing DLC and embedding "ripped by DragonSlayer" inside the DLC.  He is also taking the liberty to change the area of the DLC which indicates what title the DLC is "for".  This completely hoses xm360 which expects DLC to be intact.  So, if you are exposing yourself to these DLC files, be prepared for XM360 to not be able to display your DLC correctly...and don't report it as a bug.  Be aware, that this feature can take some real time as it has to open each and every DLC to figure out what it's name *should* be.

=-=-=-=-=-=

Version 1.1b -- Feb 26th, 2010
* some minor ftp fixes (modify time on files, and ability to CD ..)

=-=-=-=-=-=

Version 1.2 -- Mar 7th, 2010

* mostly visual changes, but they are pretty substantial.  Includes icons for XBLA titles in the lists (if you have the title).

=-=-=-=-=-=

Version 1.3 -- Mar 19th, 2010

* Added support for ntpd.  Each time you launch XM360, it will update the 360's clock (if it can connect to the ntpd) - Big Thanks to Ced2911 of team xedev!
* Added ability to configure the IP of the ntpd server (see the cfg file for more details)
* Added time display to first page
* Because some people may now use XM360 *only* to set their clock, it no longer automatically scans when starting up
* Added support for an extra path to search for XBLA titles instead of only the built in ones.  See the cfg file for more details.
* The report generated for DLC now clearly indicates DLC which you have but wasn't found when scraping the marketplace.

=-=-=-=-=-=

Version 1.3b -- Mar 20th, 2010

* Fixed focus stuck on list if you moved there before scanning
* If your startup time is very long, it's because XM360 is trying to reach the time server and can't.  Either figure out why that is, and fix it, or set your TIME_SERVER_IP to be empty in the config file and setting the time will be skipped.  
* Fixed EXTRA_XBLA_SEARCH_PATH not working (it was working, but erroneously stated that it needed a trailing slash)

=-=-=-=-=-=

Version 1.4 Preview -- Mar 28th, 2010

* There has been a TON of work put in recently, and I wanted to get a "preview" version out so that I can start hearing the bug reports/feature requests
* Instead of scanning the drive every single time, XM360 now stores the results of the scan in a local file after the scan is completed.  This is important for the following reasons: 1) If you don't "rescan" after you know there have been changes, those changes WILL NOT be reflected in XM360... So, remember to "rescan" if you have added or removed content. 2) Currently, you can't choose where this file gets stored.  It could be slow on a USB stick, and break completely if you try to turn XM360 into a LIVE package.
* There is now major support for transfering content between 360s that are running XM360.  Make sure each one has a recent "rescan".  And see the config file for information on how to configure XM360 to find your 360s on the network.  You can "push" content to another box, or "pull" content to your local box.  All content is displayed with a big "L" if it is local, and a big "R" if it is remote.  Currently, this is only implemented for XBLA titles (not DLC or TU yet).
* Transfers are initiated by clicking down on the right thumbstick.  Anyone get a better icon for this than the one I made?
* Transfer status is shown at the bottom of the screen.  I suggest you don't do anything *wrong* why the transfer is working (like launching a title).  Also, you can start multiple transfers, since it is all threaded...but in this version it really confuses the transfer status at the bottom of the screen.
* A GREAT BIG HUGE thanks to dschu012 of x-s for altering the fetchMS_DLC.pl script.  It brings the ability to match DLC based on filename instead of the title that is inside the content (which often didn't match the marketplace).  I had to make substantial changes inside XM360 to use this new format, but it was all worth it.  DLC collection management is considerably better because of this.  I suggest you remove your dlc_ignored.csv if you have one, and start over.  Also, since the format changed, make absolutely sure that if you had an alternate path set up for DLC_titles.csv that you overwrite the file that is there with the one included in this release of XM360.
* XM360 now treats 0x7000 content as XBLA, so the "gameroom", and other things will show up on the first screen.
* REMINDER: This is a "preview" release.  There are a bunch of things left on my list:
*** Add more status when connecting to remote ftp ie."Fetching Content"
*** Add a better U/I for ftp transfers (instead of using the status bar?)
*** Add display of Local/Remote to DLC and TU
*** Add Transfers to DLC and TU
*** Update the generated content.bin automatically when ftp transfers are done.

=-=-=-=-=-=

Version 1.4 -- Apr 3rd, 2010

* Since there was actually zero feedback on the "remote" capabilities allowing one XM360 to talk to another one, I've stopped working on that feature.  It's all still there, and ripe for improvement, if anyone cares.
* Added ability to sort by locked status in collection mgr
* Added support for overscan via config  (see the config file for details)
* Correctly handle 0x7000 content type (GOD/downloads) (only allow launching, don't show locked state, don't allow remote transfer)  You will have the "Rescan All" for this to take effect.
* Fixed message when unable to write a report (it used to report success, even upon failure)

=-=-=-=-=-=

Version 1.4b -- Apr 4th, 2010

* Added the ability to specify (via config) where the "content.bin" file is located.  This feature, along with a config file here: Hdd1:\config\xm360\xm360.cfg should allow XM360 to run as a LIVE container.  See config file for details.
* Fixed bug where the virtual "usb:" device (first found usb device) wasn't mounted unless you did a "Rescan All"

=-=-=-=-=-=

Version 1.5 -- May 2nd, 2010

* Added full support for game saves.  
* Added ability to have the "remote" 360 do a force-rescan when connecting to it.
* Fixed issue where ftp stopped connecting after about 20 or so connections
* Added ability to delete XBLA content on the first page (including REMOTE content)
* Added display of file size to first page
* Added support for UsbMU0: and UsbMU1: if you are using dash 9199 (including via ftp)
* Don't mount DVDROM or FLASH when starting...greatly improves startup time
* Added support for new "REPORT_PATH" in the config which will be used for all reports (XBLA, DLC, GAME SAVES)
* Added filter to the DLC page to show only DLC which wasn't "matched" (or "scraped")
* Added some more specific status messages when connecting to a remote 360
* The local content.bin (file written when you do a rescan all) is automatically updated if you fetch content via ftp or delete local content

** Just a quick note.  Fetching and pushing content still keeps the full path intact.  That means if you are trying to fetch content from a remote memory unit, for example, and you don't have a memory unit locally...it won't work.  It will fail silently.
** Also, pushing content as well as deleting remote content *doesn't* update the remote content.bin.  You should either remember to do a rescan all on that machine the next time you use it, or go to the Remote Connection button, check the Force Rescan checkbox, and reconnect to the remote machine.

=-=-=-=-=-=

Version 1.5b -- May 3rd, 2010

* Include DLC located on UsbMUx:
* Start all searches at xxx:\\Content\\ instead of xxx:\\Content\\0000000000000000 (game saves)  This means a full scan will take longer, but it's necessary.

=-=-=-=-=-=

Version 1.5c-- May 7th, 2010

* Fixed Passive FTP mode (it was always disconnecting)

=-=-=-=-=-=

Version 1.6-- May 29th, 2010

* Xm360 now includes a server component (xm360_server) that runs on the PC.  Find it in the "server" directory of the archive.
* Be sure to define hdd1: in xm360server.cfg before using it.
* This server component when running, allows you to connect to it as if it is another 360 from within xm360.  This allows you to centralize you content on a PC on your network.
* Unlike a regular 360, the server component automatically keeps its content.bin up-to-date when things are pushed to it
* I recommend pushing content to the server from xm360 to begin with to make absoultely certain that it creates the paths correctly on the PC
* xm360 now has very robust FTP job queuing, showing you what's in the queue, and the progress of each transfer right in the content list.
* Due to the fact that you may want to run the server on a port other than 21, XM360 itself now allows you to specify the port in the "Other XBOX" ftp config section.  See XM360.cfg for details.
* Lots of minor fixes in XM360 itself
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 1.6b-- May 30th, 2010

* Because Usb Memory Units (using the new NXE dash) store Title Updates in a seperate partition, I had to add support for a new partition.
* Backups and restores of TUs that are on the USB Memory Unit end up using a Cache2 directory in that same new partition
* XM360server was updated to support defining a path for this new partition (see xm360server.cfg for details), but it's useless for now since xm360 still doesn't support remote TUs
* A request was made to indicate the number of title updates found in cache2 seperately from the regular title updates.
  Both the initial scan, and the status at the bottom of the screen now show the count of "backup" title updates in parens after the regular count
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 1.7-- Jun 12th, 2010

* Add support for remote transfers to the Title Updates and DLC scenes
* xm360 server now also scans for content in \360dashit\Content on hdd1:, usb0:, usb1:, and usb2:
* When repairing DLC filenames, dlc_rename_report.txt is generated in the DLC_REPORT directory.  Reminder: You should remember to "rescan all" after a successful "repair" of filenames.
* All scenes now support MASS copying.  You get either "GET" everything, "PUT" everything, or "BOTH".  In all cases, this will affect only the titles that are shown by the current filter.
**    In other words, if you are on the DLC scene, and the <ALL> title is selected, then **ALL** DLC will be sync'd, if Guitar Hero is selected, the only Guitar Hero DLC will be sync'd.
* New values are written when unlocking content.  The first four slots are always written to be FF FF FF FF FF FF, FF FF FF FF, and then swapping between 00 00 00 00 and 00 00 00 01.
**    This is said to be more universal.  I suggest backing up content and trying it out.
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 1.7b -- Jun 19th, 2010

* NOTE NOTE NOTE: Version 1.7b is initially being released as a password protected file.  Donators have been emailed the password.
* NOTE NOTE NOTE: After a few days(?) it will be released for non-donators.
*
* Fix DLC where multiple DLCs are actually contained in the same file.  They will now display properly, get transfered properly, and get deleted properly.
* Fix ignored DLC not being remembered between session.  I broken this a couple of versions back, I think. 
* Changed code so that if you have multiple files queued up, it will only transfer one at a time.  Three at a time was cool, but one at a time is faster.
* Removed the "new unlock" that was in 1.7 until I can get a handle on why it didn't always work.  May be re-introduced later.
* Finally, and maybe most interestingly, the old perl scripts for scraping DLC and XBLA content have been rewritten in C++, and are now included as features of xm360_server.exe

Usage: XM360server.exe /? - list options
       XM360server.exe /D - update or create dlc_titles.csv in the current directory and exit
       XM360server.exe /X - update or create xbla_titles.csv in the current directory and exit
       XM360server.exe /L {locale} - optionally specify the locale (defaults to en-US).  Only useful before /D or /X
       XM360server.exe /U {URL} - optionally specify the URL (defaults to catalog.xboxlive.com).  Only useful before /D or /X
       XM360server.exe - with no parameters runs the server (doesn't exit)

Sample:
XM360server.exe /X  (update XBLA_titles.csv and exit)
XM360server.exe /U catalog.xboxlive.com /L en-US /D (update DLC_titles.csv and exit, URL and Locale specifically overridden)

* One of the key features of this is that it is no longer silent while running.  It will keep you updated on what it is working on.  Sometimes the MS server takes a long time
*   to respond, so it's best to just be patient.
*   Also, the first line of the generated CSV file is now the date that it was run on.  This allows *subsequent* runs to only UPDATE the content that MS says has changed.  This
*   saves CONSIDERABLE time.  XM360 has been modified to accept CSV file either with the date, or without...so old CSV files (or ones generated by the perl scripts) will not break
*   XM360...however, that's only true of version 1.7b and above...anything earlier will choke on a CSV file with a date at the top. 
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 1.8 -- Jun 27th, 2010

* Fixed fact that you couldn't sort by ratings or raters in the collection manager
* Fixed new scraper (1.7b) getting ratings wrong. I made a change to the file format that breaks compatibility with old xbla_titles.csv, so make sure you are not using an old version of the file.
* Fixed initial scan crashing the 360 if there was no existing content.bin file.
* xm360_server is now aware of the last time xbla_titles.csv and dlc_titles.csv were generated. Every 360 that connects to xm360_server will *automatically* update the xbla_titles.csv and dlc_titles.csv on that 360. Furthermore, you can regenerate, or replace those files without stopping xm360_server from running. So, I leave the server running all the time, 24/7. I have scheduled a /X and a /D every night at midnight as well. It's all invisible without any hands on maintenance. Basically, this feature means you shouldn't ever have to worry about moving these files to your 360 anymore. On the server, these files should be in the same place as content.bin.
* Also, if you put an xm360.xex in that same directory, xm360 will *also* update itself if the version there is newer than the version that is running. It will automatically restart if this happens. This is a moot feature though, unfortunately.
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 1.8b -- Jun 27th, 2010

* A request was made to include the DLC filename for missing DLC in the DLC_report.txt
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 1.8c -- Jul 15th, 2010

* A suggestion from a donater: The first scene now has the ability to seperate GOD from XBLA (use RB to toggle)
* The server will now wait for you to hit enter after scraping XBLA or DLC
* The server has a new command line option (/Q) to tell it *not* to wait for enter after scraping.  Use this if you automatically scrape every night via a scheduled task, or something like that.
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 1.8d -- Aug 7th, 2010

* After "ATHiEST" leaked version 1.7b, I stopped work on xm360, except to support people who had donated.  I'm releasing 1.8d to get everyone out there caught up to what has changed since then.  Any future work on XM360 will once again go to people who donated first.  
*
* Due to a request, after unlocking XBLA, you no longer have to do a full re-scan for content 
* FTP is much faster thanks to the FSD team teaching me to assign threads to a CPU, go DONATE TO FSD PLEASE!
* Because xm360_server became the only way to update the database, and it doesn't work on linux.  I've gone back to including the perl scrapers (but they are still not as good as xm360_server)
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 1.9 -- Sep 6th, 2010

* Fixed mass ftp transfers freezing
* Fixed size display of GOD titles
* Added ability to push GOD titles
* Added ability to delete LOCAL and REMOTE GOD titles
* Fixed DLC scene being off by 1 pixel
* Fixed Game Saves scene being off by 1 pixel
* Added display of path to bottom of game saves scene
* Fixed gamesave dates in server (sometimes read wrong date)
* Added auto-update from server (previous only handled xm360.xex, now will fetch media directory as well)
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 1.9a -- Sep 6th, 2010

* Fixed sync buttons for GOD content
* Fixed percentage display when transfering GOD containers
* Fixed ftp dir listing file timestamps
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com
	
=-=-=-=-=-=

Version 1.9b -- Sep 10th, 2010

* Fixed server for UsbMu0 and UsbMu1
* Removed some debugging output from the server when updating XBLA
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 2.0 -- Sep 26th, 2010

* Fixed 360 to 360 remote connections
* Added config command WRITE_REPORTS_ON_STARTUP, see xm360.cfg for more details 
* Added custom FTP command "RPTS" which will write all 3 reports
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 2.0a -- Sep 27th, 2010

* Fixed RESC ftp command followed by RPTS command
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 2.0b -- Oct 24th, 2010

* Fixed Server crashing on DLC update (missing data in the marketplace)
* Added Custom FTP command "FREE" which will dump the size/used/free for each mounted device
* Added status line information when remote ftp clients are connected, and transfering
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 2.0c -- Nov 3rd, 2010

* Found and fixed big bug in xm360server that was preventing all DLC from being recognized.
*    Unfortunately, this means that entering the DLC scene in xm360 now takes up to 10 full seconds to process the data.
* Some status messages have moved to a message box (since they disappeared in 2.0b)
* Fixed issue which was causing the xbla_excludes.csv file to not always be written
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

=-=-=-=-=-=

Version 2.0d -- Nov 13th, 2010

* Fixed seemingly never ending message boxes that I broke in 2.0c
* Changed format of XBLA and DLC reports to include Utf8, and proper quoting
*
* If you love XM360, please donate via paypal: xm360donate@gmail.com

Enjoy!
