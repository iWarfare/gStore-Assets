Script repository / examples / development / documentation available on GitHub:

https://github.com/XboxUnity/AuroraScripts/